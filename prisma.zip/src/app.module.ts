import { Module } from '@nestjs/common';
import { TasksModule } from './tasks/tasks.module';
import { UserModule } from './user/user.module';
import { CategoriesModule } from './categories/categories.module';
import { PrismaModule } from './prisma.module';


@Module({
  imports: [TasksModule, UserModule, CategoriesModule, PrismaModule],
  
})
export class AppModule {}
